// 📄 Управление JSON ядром OM_Gate_Core
