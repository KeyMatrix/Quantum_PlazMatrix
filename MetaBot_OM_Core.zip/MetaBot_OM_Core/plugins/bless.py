# Bless module

def bless():
    print('Flow blessed')