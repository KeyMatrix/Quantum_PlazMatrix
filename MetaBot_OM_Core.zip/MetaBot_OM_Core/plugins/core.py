# Core plugin for MetaBot_OM_Core

def run():
    print('MetaBot_OM_Core is active')