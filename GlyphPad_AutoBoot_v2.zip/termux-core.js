
const fs = require('fs');

fs.readFile('OM_Gate_Core_v3.json', 'utf8', (err, data) => {
  if (err) {
    console.error('Ошибка загрузки JSON:', err);
    return;
  }

  const core = JSON.parse(data);
  console.log('\n== OM GATE CORE JSON ==');
  console.log('> Название ядра:', core.name || '[не указано]');
  console.log('> Активные глифы:');
  core.glyphs.forEach((glyph, index) => {
    console.log(`  [${index + 1}] ${glyph.symbol}`);
  });
});
