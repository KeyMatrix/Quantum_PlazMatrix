# KeyMatrix: OmniSync Protocol

- REST → `/ask` → `aiAnswer()`
- WebSocket → `query` JSON → AI → Response
- Discord → `!ask` → AI
- JSON ядро: `OM_Gate_Core_v3.json` — запись и чтение
