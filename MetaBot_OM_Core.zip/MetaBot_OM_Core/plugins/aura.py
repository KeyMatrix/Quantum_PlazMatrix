# Aura plugin logic

def activate():
    print('Aura activated')