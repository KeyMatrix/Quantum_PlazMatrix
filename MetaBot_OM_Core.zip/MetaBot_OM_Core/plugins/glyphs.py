# Glyph trigger system

def trigger():
    print('Glyph triggered')