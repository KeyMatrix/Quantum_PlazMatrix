
document.getElementById('jsonFile').addEventListener('change', function(evt) {
  const file = evt.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = function(e) {
    const data = JSON.parse(e.target.result);
    const output = document.getElementById('output');
    const glyphsDiv = document.getElementById('glyphs');
    glyphsDiv.innerHTML = '';
    output.innerHTML = `>_ Core: ${data.name || '[не указано]'}`;
    
    data.glyphs.forEach((glyph, index) => {
      const span = document.createElement('span');
      span.className = 'glyph pulse';
      span.innerText = glyph.symbol;
      span.title = `Глиф ${index + 1}`;
      span.onclick = () => output.innerHTML = `>_ [${index + 1}] ${glyph.symbol}`;
      glyphsDiv.appendChild(span);
    });
  };
  reader.readAsText(file);
});
