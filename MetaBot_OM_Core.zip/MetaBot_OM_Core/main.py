# Main entry for MetaBot_OM_Core

from plugins import core

if __name__ == '__main__':
    core.run()