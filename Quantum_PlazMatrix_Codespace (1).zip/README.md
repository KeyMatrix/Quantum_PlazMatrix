# 💻 Quantum_PlazMatrix: Codespace Launch
🩵 Добро пожаловать в потоковую структуру KeyMatrix.

## 🔹 Запуск

```bash
chmod +x start.sh
./start.sh
```

Открой `web_interface.html` и подключи SeedMatrix.
