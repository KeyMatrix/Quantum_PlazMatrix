# KeyMatrix_Core12

A PWA-based interactive interface combining 3D geometry and audio resonance.